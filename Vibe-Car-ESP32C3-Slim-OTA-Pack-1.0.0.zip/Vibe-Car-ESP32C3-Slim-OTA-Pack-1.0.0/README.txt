===================================================
  ESP32-C3 Vibe Car Slim OTA Flashing Pack (946 KB)
===================================================

[Method 1: Direct Web OTA Upload (NO USB Cable Required)]
1. Connect Mobile/PC Wi-Fi to 'ESP32-Car-AP' (Pass: vibe123456).
2. Open Web Controller Dashboard at http://127.0.0.1:5173 or open http://192.168.4.1.
3. Select 'firmware_esp32c3_vibe_car_slim.bin' (946 KB).
4. Click 'Start OTA Upload'. Done!

[Method 2: Node.js 1-Click OTA Command]
Run: node ota_upload.mjs

Firmware Size: 946 KB (Fits on legacy default 1.25MB OTA partitions!)
