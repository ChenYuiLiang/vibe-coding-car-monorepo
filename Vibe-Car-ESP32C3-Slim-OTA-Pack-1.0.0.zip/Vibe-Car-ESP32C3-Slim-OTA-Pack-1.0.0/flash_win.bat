@echo off
setlocal
echo ===================================================
echo   ESP32-C3 Vibe Car Slim Flasher v1.0.0 (946 KB)
echo ===================================================
python -m pip install --user esptool
python -m esptool --chip esp32c3 erase-flash
python -m esptool --chip esp32c3 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 4MB 0x0 bins\bootloader.bin 0x8000 bins\partition-table.bin 0x10000 bins\vibe_car_firmware.bin
pause
