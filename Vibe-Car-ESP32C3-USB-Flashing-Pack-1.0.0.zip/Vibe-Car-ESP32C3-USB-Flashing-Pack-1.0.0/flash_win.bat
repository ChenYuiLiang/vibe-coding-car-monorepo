@echo off
setlocal
echo.
echo ===================================================
echo   ESP32-C3 Vibe Car One-Click USB Flasher v1.0.0
echo ===================================================
echo.
echo [1/3] Installing esptool flasher...
python -m pip install --user esptool
if errorlevel 1 (
  echo Python or pip not found. Please install Python 3 and check 'Add to PATH'.
  pause
  exit /b 1
)

echo [2/3] Erasing old flash partitions (Erasing 1.3MB legacy partition data)...
python -m esptool --chip esp32c3 erase-flash
if errorlevel 1 (
  echo.
  echo [ERROR] Could not connect to ESP32 on COM port.
  echo Please check USB data cable connection and hold BOOT button while plugging in.
  pause
  exit /b 1
)

echo [3/3] Flashing 1.9MB Dual OTA Partition Table and Vehicle Firmware...
python -m esptool --chip esp32c3 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 4MB 0x0 bins\bootloader.bin 0x8000 bins\partition-table.bin 0x10000 bins\vibe_car_firmware.bin
if errorlevel 1 (
  echo.
  echo [ERROR] Flash write failed.
  pause
  exit /b 1
)

echo.
echo ===================================================
echo   SUCCESS! 1.9MB OTA Firmware Flashed.
echo ===================================================
pause
