@echo off
setlocal
echo.
echo ===================================================
echo   ESP32-C3 Vibe Car One-Click USB Flasher v1.0.0
echo ===================================================
echo.
echo [1/2] Installing esptool flasher...
python -m pip install --user esptool
if errorlevel 1 (
  echo Python or pip not found. Please install Python 3 and check 'Add to PATH'.
  pause
  exit /b 1
)

echo [2/2] Flashing ESP32-C3 Firmware...
python -m esptool --chip esp32c3 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 4MB 0x0 bins\bootloader.bin 0x8000 bins\partition-table.bin 0x10000 bins\vibe_car_firmware.bin
if errorlevel 1 (
  echo Flashing failed. Please check USB connection and BOOT button.
  pause
  exit /b 1
)

echo.
echo ===================================================
echo   SUCCESS! ESP32-C3 Vehicle Firmware Flashed.
echo ===================================================
pause
