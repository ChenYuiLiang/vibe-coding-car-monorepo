@echo off
echo FW 1.3.0-curriculum USB Flasher
python -m pip install --user esptool
python -m esptool --chip esp32c3 erase-flash
if errorlevel 1 ( echo Hold BOOT and retry. & pause & exit /b 1 )
python -m esptool --chip esp32c3 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 4MB 0x0 bins\bootloader.bin 0x8000 bins\partition-table.bin 0xe000 bins\boot_app0.bin 0x10000 bins\vibe_car_firmware.bin
if errorlevel 1 ( echo Flash failed. & pause & exit /b 1 )
echo SUCCESS 1.3.0-curriculum
echo Join ESP32-Car-AP / vibe123456 -> http://192.168.4.1
pause
