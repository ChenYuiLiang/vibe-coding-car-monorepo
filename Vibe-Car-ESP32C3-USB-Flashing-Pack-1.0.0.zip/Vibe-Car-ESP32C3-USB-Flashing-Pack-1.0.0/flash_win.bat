@echo off
setlocal
echo.
echo ===================================================
echo   ESP32-C3 Vibe Car One-Click USB Flasher v1.0.0
echo ===================================================
echo.
echo [1/2] Installing esptool flasher...
python -m pip install --user esptool
if errorlevel 1 (
  echo Python or pip not found. Please install Python 3 and check 'Add to PATH'.
  pause
  exit /b 1
)

echo [2/2] Flashing ESP32-C3 Firmware...
python -m esptool --chip esp32c3 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 4MB 0x0 bins\bootloader.bin 0x8000 bins\partition-table.bin 0x10000 bins\vibe_car_firmware.bin
if errorlevel 1 (
  echo.
  echo =========================================================================
  echo [ERROR] Could not detect COM Serial Port (Found 0 serial ports).
  echo.
  echo Please check:
  echo 1. Make sure your USB Cable supports DATA (Not a charge-only cable).
  echo 2. Hold the 'BOOT' button on ESP32 while plugging in the USB cable.
  echo 3. Install CH340 or CP210x USB Driver on Windows.
  echo =========================================================================
  echo.
  pause
  exit /b 1
)

echo.
echo ===================================================
echo   SUCCESS! ESP32-C3 Vehicle Firmware Flashed.
echo ===================================================
pause
