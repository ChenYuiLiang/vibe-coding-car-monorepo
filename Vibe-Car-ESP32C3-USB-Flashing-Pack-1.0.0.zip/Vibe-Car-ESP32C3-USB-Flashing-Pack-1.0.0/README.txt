FW 1.3.0-curriculum (unified classroom image)
SSID ESP32-Car-AP / PASS vibe123456
Must include boot_app0 @ 0xe000
See docs/FIRMWARE-PLAYBOOK.md
