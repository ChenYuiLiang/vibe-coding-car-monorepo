===================================================
  ESP32-C3 Vibe Car One-Click USB Flashing Package
===================================================

[Windows Users - 1 Click Flash]
1. Plug ESP32-C3 into PC via USB cable.
2. Double click 'flash_win.bat'.
3. Done!

[Mac Users - Terminal Flash]
1. Plug ESP32-C3 into Mac via USB cable.
2. Open Terminal in this folder and run: bash flash_mac.sh
3. Done!

Included Files in /bins:
- bootloader.bin      (0x0000)
- partition-table.bin (0x8000)
- vibe_car_firmware.bin (0x10000)
