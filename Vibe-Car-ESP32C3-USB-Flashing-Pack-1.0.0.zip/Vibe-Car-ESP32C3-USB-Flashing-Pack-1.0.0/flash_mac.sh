#!/bin/bash
set -euo pipefail
python3 -m pip install --user esptool
python3 -m esptool --chip esp32c3 erase-flash
python3 -m esptool --chip esp32c3 --before default-reset --after hard-reset write-flash --flash-mode dio --flash-size 4MB 0x0 bins/bootloader.bin 0x8000 bins/partition-table.bin 0xe000 bins/boot_app0.bin 0x10000 bins/vibe_car_firmware.bin
echo SUCCESS 1.3.0-curriculum
