#!/bin/bash
echo "==================================================="
echo "  ESP32-C3 Vibe Car One-Click USB Flasher v1.0.0"
echo "==================================================="
python3 -m pip install --user esptool
python3 -m esptool --chip esp32c3 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 4MB 0x0 bins/bootloader.bin 0x8000 bins/partition-table.bin 0x10000 bins/vibe_car_firmware.bin
